package com.evoke.myntra;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyntraApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyntraApplication.class, args);
	}
}