
package com.evoke.myntra.service;

import java.util.List;


import com.evoke.myntra.dto.OrderResponseDto;

public interface OrderResponseService {
	public OrderResponseDto create(OrderResponseDto orderResponseDto);

	public List<OrderResponseDto> getAll();

	public OrderResponseDto update(OrderResponseDto orderResponseDto);

	public Boolean delete(Long id);

	public OrderResponseDto getById(Long id);
}
