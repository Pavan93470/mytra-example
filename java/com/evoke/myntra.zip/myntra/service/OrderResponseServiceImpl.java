
package com.evoke.myntra.service;

import java.util.ArrayList;

import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.evoke.myntra.dto.OrderResponseDto;
import com.evoke.myntra.entity.OrderResponseEntity;
import com.evoke.myntra.exception.ApiRuntimeException;
import com.evoke.myntra.repository.OrderResponseRepository;

@Service
public class OrderResponseServiceImpl implements OrderResponseService {
	private static final Logger log = LoggerFactory.getLogger(OrderResponseServiceImpl.class);

	@Autowired
	private OrderResponseRepository orderResponseRepository;
	ModelMapper mapper = new ModelMapper();

	@Override
	public OrderResponseDto create(OrderResponseDto orderResponse) {
		try {
			log.info("Address saved successfully");
			OrderResponseEntity orderResponseEntity = mapper.map(orderResponse, OrderResponseEntity.class);
			OrderResponseEntity Orderstatus = orderResponseRepository.save(orderResponseEntity);
			OrderResponseDto orderResponseDto = mapper.map(Orderstatus, OrderResponseDto.class);
			return orderResponseDto;
		} catch (Exception e) {
			log.error("", e);

		}
		return null;
	}

	@Override
	public List<OrderResponseDto> getAll() {
		List<OrderResponseEntity> order = orderResponseRepository.findAll();

		List<OrderResponseDto> orderResponseDtosList = new ArrayList<>();

		for (OrderResponseEntity orderResponseEntityRepository : order) {

			OrderResponseDto orderResponseDto = mapper.map(orderResponseEntityRepository, OrderResponseDto.class);

			orderResponseDtosList.add(orderResponseDto);

		}
		return orderResponseDtosList;
	}

	@Override
	public OrderResponseDto update(OrderResponseDto orderResponseDto) {
		return orderResponseDto;
	}

	@Override
	public Boolean delete(Long id) {
		try {
			log.info("Deleting orderstatus  for Id {}, ", id);
			OrderResponseDto orderResponse = getById(id);
			OrderResponseEntity orderResponseEntity = mapper.map(orderResponse, OrderResponseEntity.class);
			orderResponseRepository.delete(orderResponseEntity);
			return true;
		} catch (Exception e) {
			log.error("Error while deleting order for Id : {}", id);
			throw new ApiRuntimeException("Error while deleting  adress for Id " + id, "INTERNAL_ERROR",
					HttpStatus.INTERNAL_SERVER_ERROR);
		}

	}

	@Override
	public OrderResponseDto getById(Long id) {
		log.info("Getting ItemDetails  for Id {}, ", id);
		Optional<OrderResponseEntity> orderResponseEntityOptional = orderResponseRepository.findById(id);
		if (orderResponseEntityOptional.isPresent()) {

			OrderResponseEntity orderResponseEntity = orderResponseEntityOptional.get();
			OrderResponseDto orderResponseDto = mapper.map(orderResponseEntity, OrderResponseDto.class);

			return orderResponseDto;
		}
		log.error("order not found for Id : {}", id);
		throw new ApiRuntimeException("order Not Found for ID: " + id, "NOT_FOUND", HttpStatus.NOT_FOUND);
	}
}
